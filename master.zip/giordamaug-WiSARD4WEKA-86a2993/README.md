# WiSARD4WEKA
A supervised classification method for WEKA based on weightless neural networks.

# Install

You can install WiSARD4WEKA from the the PackageManager of your WEKA distribution, or via the command line:

<code>
java -cp <your-path-to-weka.jar> weka.core.WekaPackageManager -install-package https://github.com/giordamaug/WiSARD4WEKA/blob/master/dist/WiSARD.zip
</code>
